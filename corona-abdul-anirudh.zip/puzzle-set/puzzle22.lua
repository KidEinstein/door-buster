puzzle = {
	swipes = {
		{start = {x=4,y=6}, finish = {x=2,y=4}},
		{start = {x=6,y=4}, finish = {x=4,y=6}},
		{start = {x=4,y=2}, finish = {x=6,y=4}},
		{start = {x=2,y=4}, finish = {x=4,y=2}},

	},
	dummyDots = {
		{x=1, y=5},
		{x=4, y=4},
		{x=6, y=2},

	},
}
return puzzle


