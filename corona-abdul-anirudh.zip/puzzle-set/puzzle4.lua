puzzle = {
	dummyDots = {
		{x=1, y=2},
		{x=5, y=5}
	},
	dots = {
		{x=1, y=5, taps=1},
		{x=3, y=4, taps=2},
		{x=5, y=3, taps=1}
	},
}
return puzzle

