puzzle = {
	swipes = {
		{start = {x=1,y=2}, finish = {x=1,y=5}},
		{start = {x=3,y=4}, finish = {x=3,y=3}},
		{start = {x=5,y=5}, finish = {x=5,y=2}},
	}
}
return puzzle

