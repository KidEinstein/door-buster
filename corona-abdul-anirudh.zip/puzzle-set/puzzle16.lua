puzzle = {
	swipes = {
		{start = {x=2,y=2}, finish = {x=5,y=4}},
		{start = {x=5,y=2}, finish = {x=2,y=4}},
		{start = {x=5,y=5}, finish = {x=2,y=5}},
	},
}
return puzzle

