puzzle = {
	dummyDots = {
		{x=3, y=3},
		{x=5, y=3}
	},
	dots = {
		{x=2, y=2, taps=2},
		{x=2, y=4, taps=1},
		{x=4, y=2, taps=1},
		{x=4, y=4, taps=2},
		{x=6, y=2, taps=2},
		{x=6, y=4, taps=1},
	},
}
return puzzle

