puzzle = {
	swipes = {
		{start = {x=5,y=5}, finish = {x=6,y=4}},
		{start = {x=5,y=2}, finish = {x=5,y=2}},
		{start = {x=1,y=4}, finish = {x=2,y=5}},

	},
	dots = {
		{x=2, y=2, taps=2},
		{x=5, y=2, taps=2},
	},
}
return puzzle


