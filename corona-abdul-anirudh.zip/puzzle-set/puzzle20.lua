puzzle = {
	swipes = {
		{start = {x=2,y=5}, finish = {x=5,y=5}},
	},
	dummyDots = {
		{x=2, y=4},
		{x=2, y=6},

	},
	dots = {
		{x=2, y=2, taps=1},
		{x=3, y=3, taps=2},
		{x=5, y=2, taps=1},
		{x=3, y=4, taps=2},
	},
}
return puzzle


