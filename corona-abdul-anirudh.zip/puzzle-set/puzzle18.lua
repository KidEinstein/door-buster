puzzle = {
	swipes = {
		{start = {x=4,y=5}, finish = {x=2,y=3}},
		{start = {x=5,y=2}, finish = {x=4,y=5}},
	},
	dummyDots = {
		{x=4, y=1},
		{x=4, y=3},
	},
	dots = {
		{x=4, y=2, taps=2},
		{x=4, y=4, taps=2},
	},
}
return puzzle


