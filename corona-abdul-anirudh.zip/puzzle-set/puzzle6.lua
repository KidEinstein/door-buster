puzzle = {
	swipes = {
		{start = {x=2,y=3}, finish = {x=5,y=3}},
	}	
}
return puzzle

