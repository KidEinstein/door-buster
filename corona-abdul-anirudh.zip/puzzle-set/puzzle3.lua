puzzle = {
	dots = {
		{x=2, y=2, taps=1},
		{x=1, y=4, taps=2},
		{x=5, y=4, taps=2}
	},
}
return puzzle