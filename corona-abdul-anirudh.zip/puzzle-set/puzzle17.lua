puzzle = {
	swipes = {
		{start = {x=3,y=3}, finish = {x=3,y=5}},
	},
	
	dots = {
		{x=2, y=2, taps=1},
		{x=2, y=4, taps=2},
		{x=5, y=2, taps=2},
		{x=5, y=4, taps=1},
	},
}
return puzzle


