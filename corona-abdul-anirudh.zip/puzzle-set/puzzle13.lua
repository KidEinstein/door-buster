puzzle = {
	swipes = {
		{start = {x=3,y=4}, finish = {x=3,y=6}},
	},
	dummyDots = {
		{x=3, y=2},
	},
	dots = {
		{x=1, y=2, taps=1},
		{x=5, y=2, taps=2},
	},
}
return puzzle


