puzzle = {
	dummyDots = {
		{x=2, y=4},
		{x=5, y=2}
	},
	dots = {
		{x=6, y=6, taps=2},
	},
	swipes = {
		{start = {x=3,y=2}, finish = {x=5,y=4}},
	}
}
return puzzle

