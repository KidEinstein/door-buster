puzzle = {
	swipes = {
		{start = {x=2,y=6}, finish = {x=5,y=6}},
	},
	dummyDots = {
		{x=3, y=3},
		{x=4, y=3},
	},
	dots = {
		{x=2, y=2, taps=2},
		{x=5, y=2, taps=1},
		{x=2, y=4, taps=1},
		{x=5, y=4, taps=2},
	},
}
return puzzle


