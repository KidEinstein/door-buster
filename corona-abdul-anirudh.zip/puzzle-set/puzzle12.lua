puzzle = {
	swipes = {
		{start = {x=6,y=3}, finish = {x=4,y=1}},
		{start = {x=2,y=2}, finish = {x=4,y=4}},
		{start = {x=3,y=6}, finish = {x=1,y=4}},
	}
}
return puzzle

