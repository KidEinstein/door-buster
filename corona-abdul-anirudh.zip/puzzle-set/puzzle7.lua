puzzle = {
	swipes = {
		{start = {x=1,y=2}, finish = {x=1,y=5}},
	},
	dots = {
		{x=4, y=2, taps=1},
		{x=2, y=4, taps=1},
	},
}
return puzzle

