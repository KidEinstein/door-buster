puzzle = {
	swipes = {
		{start = {x=3,y=1}, finish = {x=3,y=3}},
		{start = {x=4,y=6}, finish = {x=4,y=2}},
	},
	dummyDots = {
		{x=3, y=4},
	},
	dots = {
		{x=5, y=3, taps=1},
		{x=2, y=5, taps=2},
	},
}
return puzzle


