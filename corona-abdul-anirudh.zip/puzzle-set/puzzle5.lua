puzzle = {
	dots = {
		{x=3, y=2, taps=2},
		{x=3, y=4, taps=2},
		{x=3, y=6, taps=2}
	},
}
return puzzle

