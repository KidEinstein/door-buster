puzzle = {
	swipes = {
		{start = {x=2,y=4}, finish = {x=4,y=5}},
	},
	dummyDots = {
		{x=5, y=6},
	},
	dots = {
		{x=1, y=2, taps=2},
		{x=3, y=2, taps=1},
		{x=5, y=2, taps=1},
		{x=2, y=5, taps=1},
	},
}
return puzzle

