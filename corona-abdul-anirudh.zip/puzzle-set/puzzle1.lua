puzzle = {
	dots = {
		{x=2, y=2, taps=1},
		{x=5, y=4, taps=1},
	},
}
return puzzle