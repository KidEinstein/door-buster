puzzle = {
	swipes = {
		{start = {x=1,y=6}, finish = {x=6,y=6}},
		{start = {x=1,y=3}, finish = {x=6,y=6}},
		{start = {x=6,y=1}, finish = {x=6,y=6}},
		{start = {x=3,y=1}, finish = {x=6,y=1}},

	},
	dots = {
		{x=4, y=3, taps=2},
	},
}
return puzzle


