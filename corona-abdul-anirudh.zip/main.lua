-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local composer = require("composer")

system.activate( "multitouch" )

composer.gotoScene( "start" )

