puzzles = {}
for i = 1, 24 do
	puzzles[#puzzles + 1] = "puzzle-set.puzzle" .. i;
end

return puzzles